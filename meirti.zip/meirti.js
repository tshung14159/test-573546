const puppeteer = require('puppeteer');
const downloader = require('image-downloader');
const fs = require('fs');
const downloadFolder = './downloads';

async function getImageUrls(url) {
    const browser = await puppeteer.launch();
    const page = await browser.newPage();
    page.setViewport({ width: 1280, height:720 });
    await page.setRequestInterception(true);
    page.on('request', request => {
        if (['image', 'stylesheet', 'font', 'script'].includes(request.resourceType())) 
            request.respond({
                status: 200,
                body: "foo"
            })
        else
            request.continue();
    });
    await page.goto(url);
    
    const imageUrls = await page.evaluate(() => {
        const items = Array.from( document.querySelectorAll('.gallery-item a') );
        const imgs = items.map( i => i.getAttribute('href'));
        return imgs;
    });

    // const keywords = document.querySelectorAll('meta[name="keywords"]')[0].content;
    
    await browser.close();
    return imageUrls;
}

function getFolderSaveNameFromUrl(url) {
    const t1 = url.split('/');
    const t2 = (t1[t1.length-1]).split('.');
    const postId = t2[0];
    return postId;
}

async function main() {
    const urls = [
        'https://www.meirti.com/493228.html',
        'https://www.meirti.com/349097.html',
        'https://www.meirti.com/363951.html',
        'https://www.meirti.com/364042.html',
        'https://www.meirti.com/370448.html',
        'https://www.meirti.com/517972.html',
        'https://www.meirti.com/511270.html',
        'https://www.meirti.com/498173.html',
        'https://www.meirti.com/492542.html',
        'https://www.meirti.com/487833.html',
        'https://www.meirti.com/481985.html',
        'https://www.meirti.com/478065.html',
        'https://www.meirti.com/470737.html',
        'https://www.meirti.com/463108.html',
        'https://www.meirti.com/446263.html',
        'https://www.meirti.com/443392.html',
        'https://www.meirti.com/441210.html',
        'https://www.meirti.com/441164.html',
        'https://www.meirti.com/441113.html',
        'https://www.meirti.com/428656.html',
        'https://www.meirti.com/424630.html',
        'https://www.meirti.com/397873.html',
        'https://www.meirti.com/387434.html',
        'https://www.meirti.com/378208.html',
        'https://www.meirti.com/378135.html',
        'https://www.meirti.com/493862.html',
        'https://www.meirti.com/493186.html',
        'https://www.meirti.com/443350.html',
        'https://www.meirti.com/387392.html',
        'https://www.meirti.com/363915.html',
        'https://www.meirti.com/348740.html',
        'https://www.meirti.com/321253.html',
        'https://www.meirti.com/321218.html',
        'https://www.meirti.com/274746.html',
        'https://www.meirti.com/274704.html',
        'https://www.meirti.com/196234.html',
    ];

    urls.forEach( async url => {
        const postId = getFolderSaveNameFromUrl(url);
        const saveFolder = downloadFolder + '/' + postId;
        const imageUrls = await getImageUrls( url );

        if ( ! fs.existsSync( saveFolder) ) {
            fs.mkdirSync(saveFolder);
        }
        for ( let i = 0; i < imageUrls.length; i++ ) {
            await downloader.image({
                url: imageUrls[i],
                dest: saveFolder
            })
        }
        
        console.log('Done !');
    } );


}

main();